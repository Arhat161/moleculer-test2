"use strict";

module.exports = {
  name: "sqrt",
  // экшены для экспорта (для использования в модуле)
  actions: {
    returnSqrt(ctx) {
      return this.getSqrt(ctx);
    },
    returnSum(ctx) {
      return this.getSum(ctx);
    },
    returnSub(ctx) {
      return this.getSub(ctx);
    },
    returnDiv(ctx) {
      return this.getDiv(ctx);
    },
    returnMult(ctx) {
      return this.getMult(ctx);
    },
  },
  // методы миксина
  methods: {
    // сумма двух чисел
    getSum: {
      params: {
        a: "number",
        b: "number",
      },
      handler(ctx) {
        let a = Number(ctx.params.a);
        let b = Number(ctx.params.b);
        return a + b;
      },
    },
    // разность двух чисел
    getSub: {
      params: {
        a: "number",
        b: "number",
      },
      handler(ctx) {
        return Number(ctx.params.a) - Number(ctx.params.b);
      },
    },
    // деление числа A на число B
    getDiv: {
      params: {
        a: "number",
        b: "number",
      },
      handler(ctx) {
        let a = Number(ctx.params.a);
        let b = Number(ctx.params.b);
        if (b != 0 && !Number.isNaN(b)) return a / b;
        else throw new MoleculerError("Divide by zero!", 422, null, ctx.params);
      },
    },
    // умножение числа A на число B
    getMult: {
      params: {
        a: "number",
        b: "number",
      },
      handler(ctx) {
        return Number(ctx.params.a) * Number(ctx.params.b);
      },
    },
    // корень квадратный
    getSqrt: {
      params: {
        a: "number",
      },
      handler(ctx) {
        let a = Number(ctx.params.a);
        if (a != 0 && !Number.isNaN(a)) return Math.sqrt(a);
        else throw new MoleculerError("Zero!", 422, null, ctx.params);
      },
    },
  },
};
