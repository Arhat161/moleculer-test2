const { MoleculerError } = require("moleculer").Errors;

const ApiService = require("moleculer-web");

const SqrtService = require("../mixins/math.operations");

module.exports = {
  name: "calc",
  mixins: [ApiService, SqrtService],
  //actions: {},
  settings: {
    routes: [
      {
        path: "/api/calc",
        whitelist: [
          // Access any actions in 'math' service
          /^calc\.\w+$/,
        ],
        aliases: {
          add: "calc.returnSum",
          sub: "calc.returnSub",
          mult: "calc.returnMult",
          div: "calc.returnDiv",
          sqrt: "calc.returnSqrt",
        },
      },
    ],
  },
};

// node node_modules/moleculer/bin/moleculer-runner --hot --repl services\simple.service.js
// actions
// call math.div --a 120 --b 12
